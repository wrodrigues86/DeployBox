module.exports = {
  handle: async ({ res, projectRoot, req }) => {
    const requestPath = req.path.split('/').slice(2).join('/') || 'index.html'
    const file = require('node:path').join(projectRoot, 'public', requestPath)
    return res.sendFile(file)
  }
}