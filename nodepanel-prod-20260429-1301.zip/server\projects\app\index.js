module.exports = {
handle: async ({ res, projectRoot, req }) => {
  return res.send(`
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
      <meta charset="UTF-8">
      <title>Teste</title>
    </head>
    <body>
      <h1>Olá mundo</h1>
      <p>HTML enviado direto pela função.</p>
    </body>
    </html>
  `)
}
}