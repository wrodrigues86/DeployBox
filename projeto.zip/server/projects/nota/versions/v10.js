const path = require('node:path');
const Database = require('better-sqlite3');

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

module.exports = {
  handle: async ({ res, projectRoot, req, body }) => {
    let db;

    try {
      const dbPath = path.join(projectRoot, 'notas.db');
      db = new Database(dbPath);

      db.prepare(`
        CREATE TABLE IF NOT EXISTS notas (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          titulo TEXT NOT NULL,
          descricao TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `).run();

      if (req.method === 'POST') {
        const titulo = String(body?.titulo || '').trim();
        const descricao = String(body?.descricao || '').trim();

        if (!titulo) {
          return res.status(400).type('html').send(`
            <h1>Erro</h1>
            <p>Titulo obrigatorio.</p>
          `);
        }

        db.prepare(`
          INSERT INTO notas (titulo, descricao)
          VALUES (?, ?)
        `).run(titulo, descricao);

        return res.redirect(303, req.originalUrl || req.url);
      }

      const notas = db.prepare(`
        SELECT id, titulo, descricao, created_at
        FROM notas
        ORDER BY id DESC
      `).all();

      return res.type('html').send(`
        <!doctype html>
        <html lang="pt-BR">
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Cadastrar Nota</title>
          </head>
          <body>
            <h1>Cadastrar Nota</h1>

            <p><strong>Banco:</strong> ${escapeHtml(dbPath)}</p>

            <form method="POST">
              <input name="titulo" placeholder="Titulo" required>
              <br><br>

              <textarea name="descricao" placeholder="Descricao"></textarea>
              <br><br>

              <button type="submit">Salvar</button>
            </form>

            <hr>

            <h2>Notas</h2>

            ${notas.length
          ? notas.map((nota) => `
                    <div style="border:1px solid #ccc;padding:10px;margin:10px 0;">
                      <strong>${escapeHtml(nota.titulo)}</strong>
                      <p>${escapeHtml(nota.descricao)}</p>
                      <small>${escapeHtml(nota.created_at)}</small>
                    </div>
                  `).join('')
          : '<p>Nenhuma nota cadastrada.</p>'
        }
          </body>
        </html>
      `);
    } catch (erro) {
      console.error(erro);

      return res.status(500).type('html').send(`
        <h1>Erro</h1>
        <pre>${escapeHtml(erro.stack || erro.message)}</pre>
      `);
    } finally {
      if (db) db.close();
    }
  },
};
