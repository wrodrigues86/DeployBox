module.exports = {
  config: { auth: true },
  routes: {
    "/": ({ env }) => ({ app: env.APP_NAME || "Lista de produtos1111" })
  }
}