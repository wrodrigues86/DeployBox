module.exports = {
  config: {
    auth: true
  },

  clientes: () => {
    return [
      {
        id: 1,
        nome: "João Silva",
        email: "joao@email.com",
        telefone: "11999990001",
        cidade: "São Paulo",
        status: "ativo"
      },
      {
        id: 2,
        nome: "Maria Souza",
        email: "maria@email.com",
        telefone: "21999990002",
        cidade: "Rio de Janeiro",
        status: "ativo"
      },
      {
        id: 3,
        nome: "Carlos Lima",
        email: "carlos@email.com",
        telefone: "31999990003",
        cidade: "Belo Horizonte",
        status: "inativo"
      },
      {
        id: 4,
        nome: "Fernanda Rocha",
        email: "fernanda@email.com",
        telefone: "41999990004",
        cidade: "Curitiba",
        status: "ativo"
      },
      {
        id: 5,
        nome: "Lucas Martins",
        email: "lucas@email.com",
        telefone: "51999990005",
        cidade: "Porto Alegre",
        status: "ativo"
      }
    ];
  },

  routes: {
    "/": function () {
      return this.clientes();
    }
  }
};